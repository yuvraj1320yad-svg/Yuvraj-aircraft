package com.airtouch.mobile

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import kotlin.math.exp

/** Full-screen, touch-through overlay that draws the air cursor and glides it smoothly every frame. */
class CursorView(ctx: Context) : View(ctx) {
    companion object {
        const val MOVE = 0; const val PINCH = 1; const val DRAG = 2
        const val SCROLL = 3; const val BACK = 4; const val HIDDEN = 5
        private const val GLIDE_TAU = 0.030f
    }

    @Volatile var tx = 0f
    @Volatile var ty = 0f
    @Volatile var mode = HIDDEN
    @Volatile var snap = true

    private var x = 0f
    private var y = 0f
    private var last = 0L
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 7f }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }

    private fun colorFor(m: Int) = when (m) {
        PINCH -> 0xFF00E676.toInt()
        DRAG -> 0xFFFF9100.toInt()
        SCROLL -> 0xFFFFEA00.toInt()
        BACK -> 0xFFFF1744.toInt()
        else -> 0xFF00B7FF.toInt()
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = ((now - last) / 1e9f).coerceIn(0.001f, 0.1f)
        last = now
        if (snap) { x = tx; y = ty; snap = false }
        else {
            val a = 1f - exp(-dt / GLIDE_TAU)
            x += (tx - x) * a
            y += (ty - y) * a
        }
        val m = mode
        if (m != HIDDEN) {
            ring.color = colorFor(m)
            c.drawCircle(x, y, if (m == MOVE) 30f else 22f, ring)
            c.drawCircle(x, y, 7f, dot)
        }
        postInvalidateOnAnimation()
    }
}
