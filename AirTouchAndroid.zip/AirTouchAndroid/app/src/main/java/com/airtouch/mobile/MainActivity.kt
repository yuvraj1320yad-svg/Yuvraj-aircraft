package com.airtouch.mobile

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
            gravity = Gravity.TOP
        }
        root.addView(TextView(this).apply { text = "Air Touch"; textSize = 28f })
        status = TextView(this).apply { textSize = 16f; setPadding(0, 32, 0, 32) }
        root.addView(status)

        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply {
            text = t; setOnClickListener { f() }
        })

        btn("1. Accessibility ON karo (Air Touch)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("2. 'Display over other apps' ON karo") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("3. Camera + Notification permission") {
            val p = mutableListOf(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 1)
        }
        btn("START") {
            if (!allOk()) Toast.makeText(this, "Pehle upar ke teeno step poore karo", Toast.LENGTH_LONG).show()
            else startForegroundService(Intent(this, TrackingService::class.java))
        }
        btn("STOP") { stopService(Intent(this, TrackingService::class.java)) }

        root.addView(TextView(this).apply {
            textSize = 14f; setPadding(0, 32, 0, 0)
            text = "Gestures:\n" +
                "• Index finger up = cursor move\n" +
                "• Thumb+Index pinch = tap (hold = drag)\n" +
                "• Thumb+Middle pinch = Back\n" +
                "• Index+Middle up = scroll (haath upar/neeche)"
        })
        setContentView(root)
    }

    override fun onResume() { super.onResume(); refresh() }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r); refresh()
    }

    private fun cam() = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    private fun acc() = TouchService.instance != null
    private fun ovl() = Settings.canDrawOverlays(this)
    private fun allOk() = cam() && acc() && ovl()

    private fun refresh() {
        fun m(b: Boolean) = if (b) "✅" else "❌"
        status.text = "${m(acc())} Accessibility\n${m(ovl())} Display over other apps\n${m(cam())} Camera"
    }
}
