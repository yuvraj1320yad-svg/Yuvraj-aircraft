package com.airtouch.mobile

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/** Injects taps, drags, swipes and Back into the whole phone (this is what replaces the PC mouse). */
class TouchService : AccessibilityService() {
    companion object {
        @Volatile var instance: TouchService? = null
    }

    private val h = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------- tap / back ----------
    fun tap(x: Float, y: Float) {
        h.post {
            val p = Path().apply { moveTo(x, y) }
            dispatchGesture(GestureDescription.Builder().addStroke(StrokeDescription(p, 0, 50)).build(), null, null)
        }
    }

    fun back() { h.post { performGlobalAction(GLOBAL_ACTION_BACK) } }

    // ---------- scroll (swipe), one at a time ----------
    @Volatile private var swipeBusy = false

    /** Returns false if the previous swipe is still running (caller keeps accumulating). */
    fun swipe(x: Float, y0: Float, y1: Float): Boolean {
        if (swipeBusy) return false
        swipeBusy = true
        h.post {
            val p = Path().apply { moveTo(x, y0); lineTo(x, y1) }
            val cb = object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { swipeBusy = false }
                override fun onCancelled(g: GestureDescription?) { swipeBusy = false }
            }
            val ok = dispatchGesture(
                GestureDescription.Builder().addStroke(StrokeDescription(p, 0, 110)).build(), cb, null)
            if (!ok) swipeBusy = false
        }
        return true
    }

    // ---------- drag: one long stroke that keeps continuing ----------
    private var dragStroke: StrokeDescription? = null
    private var busy = false
    private var ending = false
    private var hasPend = false
    private var pendX = 0f
    private var pendY = 0f
    private var lastX = 0f
    private var lastY = 0f

    fun dragStart(x: Float, y: Float) {
        h.post {
            lastX = x; lastY = y; hasPend = false; ending = false
            val s = StrokeDescription(Path().apply { moveTo(x, y) }, 0, 20, true)
            dragStroke = s
            busy = true
            send(s)
        }
    }

    fun dragMove(x: Float, y: Float) {
        h.post {
            if (dragStroke == null) return@post
            pendX = x; pendY = y; hasPend = true
            if (!busy) step()
        }
    }

    fun dragEnd() {
        h.post {
            if (dragStroke == null) return@post
            ending = true
            if (!busy) step()
        }
    }

    private fun step() {
        val s = dragStroke ?: return
        if (!hasPend && !ending) return
        val tx = if (hasPend) pendX else lastX
        val ty = if (hasPend) pendY else lastY
        hasPend = false
        val cont = !ending
        val path = Path().apply { moveTo(lastX, lastY); lineTo(tx, ty) }
        val next = s.continueStroke(path, 0, 16, cont)
        lastX = tx; lastY = ty
        dragStroke = if (cont) next else null
        if (!cont) ending = false
        busy = true
        send(next)
    }

    private fun send(s: StrokeDescription) {
        val cb = object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { busy = false; step() }
            override fun onCancelled(g: GestureDescription?) {
                busy = false; dragStroke = null; hasPend = false; ending = false
            }
        }
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(s).build(), cb, null)
        if (!ok) { busy = false; dragStroke = null }
    }
}
