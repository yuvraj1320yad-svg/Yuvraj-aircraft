package com.airtouch.mobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.util.Size
import android.view.WindowManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import kotlin.concurrent.thread
import kotlin.math.hypot
import kotlin.math.max

/**
 * Front camera -> MediaPipe hand landmarks -> same gesture logic as the PC script
 * -> overlay cursor + taps / drag / scroll through TouchService.
 */
class TrackingService : LifecycleService() {
    companion object {
        const val ACTION_STOP = "com.airtouch.mobile.STOP"
        private const val CH = "airtouch"
        private const val TAG = "AirTouch"
        private const val MODEL_URL =
            "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"

        // ---- settings (same names/values as the PC script) ----
        const val EDGE_REACH = 1.0f
        val ANCHOR = arrayOf(0 to 0.15f, 5 to 0.20f, 9 to 0.25f, 13 to 0.25f, 17 to 0.15f)
        const val MIN_CUTOFF = 1.0f
        const val BETA = 40.0f
        const val D_CUTOFF = 1.0f
        const val PREDICT_SEC = 0.025f
        const val PINCH_ON = 0.30f
        const val PINCH_OFF = 0.42f
        const val DRAG_HOLD_SEC = 0.45
        const val CLICK_COOLDOWN = 0.10
        const val BACK_COOLDOWN = 0.6
        const val SCROLL_ENTER_SEC = 0.20
        const val SCROLL_DEADZONE = 0.004f
        const val SCROLL_GAIN_PX = 2500f   // pixels per unit of hand movement
        const val SCROLL_DIR = 1f          // phone me scroll ulta lage to -1f kar do
        const val SCROLL_MIN_PX = 50f
        const val HAND_LOST_SEC = 0.5
    }

    private lateinit var wm: WindowManager
    private var cursor: CursorView? = null
    private var landmarker: HandLandmarker? = null
    private val camExec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private var screenW = 1080
    private var screenH = 1920
    @Volatile private var frameW = 480
    @Volatile private var frameH = 640
    private var lastTs = 0L

    private val fx = OneEuro(MIN_CUTOFF, BETA, D_CUTOFF)
    private val fy = OneEuro(MIN_CUTOFF, BETA, D_CUTOFF)
    private val mg = floatArrayOf(0.08f, 0.15f, 0.08f)

    private var lastSeen = 0.0
    private var pinchL = false
    private var pinchR = false
    private var dragging = false
    private var pinchStart = 0.0
    private var lastClick = 0.0
    private var lastBack = 0.0
    private var pinchX = 0f
    private var pinchY = 0f
    private var cx = 0f
    private var cy = 0f
    private var scrollSince = -1.0
    private var scrollMode = false
    private var scrollPrev = Float.NaN
    private var scrollAcc = 0f

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels

        try {
            val v = CursorView(this)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            wm.addView(v, lp)
            cursor = v
        } catch (e: Exception) {
            Log.e(TAG, "overlay failed", e)
            stopSelf(); return
        }

        thread(name = "airtouch-init") {
            try {
                val model = ensureModel()
                landmarker = buildLandmarker(model)
                main.post { startCamera() }
            } catch (e: Exception) {
                Log.e(TAG, "init failed", e)
                main.post { stopSelf() }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { TouchService.instance?.dragEnd() } catch (_: Exception) {}
        try { ProcessCameraProvider.getInstance(this).get().unbindAll() } catch (_: Exception) {}
        try { landmarker?.close() } catch (_: Exception) {}
        try { cursor?.let { wm.removeView(it) } } catch (_: Exception) {}
        camExec.shutdown()
        super.onDestroy()
    }

    // ---------------- setup ----------------
    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Air Touch", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, TrackingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Air Touch chal raha hai")
            .setContentText("Band karne ke liye yahan tap karo")
            .setContentIntent(stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        else startForeground(1, n)
    }

    private fun ensureModel(): String {
        val f = File(filesDir, "hand_landmarker.task")
        if (f.exists() && f.length() > 100_000) return f.absolutePath
        val tmp = File(filesDir, "hand_landmarker.download")
        val c = URL(MODEL_URL).openConnection() as HttpURLConnection
        c.connectTimeout = 20000; c.readTimeout = 45000
        c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        if (tmp.length() < 100_000) { tmp.delete(); throw RuntimeException("model download failed") }
        tmp.renameTo(f)
        return f.absolutePath
    }

    private fun buildLandmarker(path: String): HandLandmarker {
        fun make(d: Delegate): HandLandmarker {
            val opts = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath(path).setDelegate(d).build())
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setResultListener { res, _ -> onResult(res) }
                .setErrorListener { e -> Log.e(TAG, "mp error", e) }
                .build()
            return HandLandmarker.createFromOptions(this, opts)
        }
        return try { make(Delegate.GPU) } catch (e: Exception) {
            Log.w(TAG, "GPU delegate failed, using CPU", e); make(Delegate.CPU)
        }
    }

    @Suppress("DEPRECATION")
    private fun startCamera() {
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            val provider = fut.get()
            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(480, 640))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(camExec) { analyze(it) }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(img: ImageProxy) {
        try {
            val lm = landmarker ?: return
            val bmp = img.toBitmap()
            // upright + mirrored, like cv2.flip(frame, 1) on the PC
            val m = Matrix().apply {
                postRotate(img.imageInfo.rotationDegrees.toFloat())
                postScale(-1f, 1f)
            }
            val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            frameW = out.width; frameH = out.height
            var ts = SystemClock.uptimeMillis()
            if (ts <= lastTs) ts = lastTs + 1
            lastTs = ts
            lm.detectAsync(BitmapImageBuilder(out).build(), ts)
        } catch (e: Exception) {
            Log.e(TAG, "analyze", e)
        } finally {
            img.close()
        }
    }

    // ---------------- gesture logic (port of the PC script) ----------------
    private fun d(a: NormalizedLandmark, b: NormalizedLandmark) = hypot(a.x() - b.x(), a.y() - b.y())

    private fun releaseDrag() {
        if (dragging) { TouchService.instance?.dragEnd(); dragging = false }
    }

    private fun resetGestures() {
        releaseDrag()
        pinchL = false; pinchR = false
        scrollPrev = Float.NaN; scrollAcc = 0f; scrollSince = -1.0; scrollMode = false
    }

    private fun onResult(res: HandLandmarkerResult) {
        val now = SystemClock.uptimeMillis() / 1000.0
        val lm = res.landmarks().firstOrNull()
        val cur = cursor ?: return
        if (lm == null) {
            if (now - lastSeen > HAND_LOST_SEC) {
                fx.reset(); fy.reset(); resetGestures(); cur.mode = CursorView.HIDDEN
            }
            return
        }
        lastSeen = now
        val touch = TouchService.instance
        val W = frameW.toFloat(); val H = frameH.toFloat()

        // margins follow hand size so the palm centre can reach every screen edge
        val palmPx = hypot((lm[5].x() - lm[17].x()) * W, (lm[5].y() - lm[17].y()) * H)
        val t0 = (EDGE_REACH * 0.9f * palmPx / W).coerceIn(0.02f, 0.22f)
        val t1 = (EDGE_REACH * 1.2f * palmPx / H).coerceIn(0.03f, 0.30f)
        val t2 = (EDGE_REACH * 0.7f * palmPx / H).coerceIn(0.02f, 0.20f)
        mg[0] += 0.03f * (t0 - mg[0]); mg[1] += 0.03f * (t1 - mg[1]); mg[2] += 0.03f * (t2 - mg[2])

        fun up(tip: Int, pip: Int) = d(lm[0], lm[tip]) > d(lm[0], lm[pip]) * 1.05f
        val idx = up(8, 6); val mid = up(12, 10); val ring = up(16, 14); val pinky = up(20, 18)
        val hsize = max(d(lm[0], lm[9]), 1e-6f)
        val dL = d(lm[4], lm[8]) / hsize
        val dR = d(lm[4], lm[12]) / hsize

        val scrollPose = idx && mid && !ring && !pinky && dL > PINCH_OFF
        if (scrollPose) {
            if (scrollSince < 0) scrollSince = now
            scrollMode = now - scrollSince >= SCROLL_ENTER_SEC
        } else { scrollSince = -1.0; scrollMode = false }

        if (scrollMode) {
            releaseDrag(); pinchL = false; pinchR = false
            cur.mode = CursorView.SCROLL
            val cyHand = (lm[8].y() + lm[12].y()) / 2f
            if (!scrollPrev.isNaN()) {
                val delta = (scrollPrev - cyHand) / (hsize / 0.18f)
                if (kotlin.math.abs(delta) > SCROLL_DEADZONE) scrollAcc += delta * SCROLL_GAIN_PX * SCROLL_DIR
            }
            scrollPrev = cyHand
            if (kotlin.math.abs(scrollAcc) >= SCROLL_MIN_PX && touch != null) {
                val amt = scrollAcc.coerceIn(-screenH * 0.4f, screenH * 0.4f)
                val half = kotlin.math.abs(amt) / 2f
                val mid2 = cy.coerceIn(half + 60f, screenH - half - 60f)
                if (touch.swipe(cx, mid2 - amt / 2f, mid2 + amt / 2f)) scrollAcc = 0f
            }
            return
        }
        scrollPrev = Float.NaN; scrollAcc = 0f

        // ---- left pinch: click / drag ----
        if (!pinchL && !pinchR && dL < PINCH_ON) {
            pinchL = true; pinchStart = now; pinchX = cx; pinchY = cy
        } else if (pinchL && dL > PINCH_OFF) {
            pinchL = false
            if (dragging) releaseDrag()
            else if (now - lastClick > CLICK_COOLDOWN) { touch?.tap(pinchX, pinchY); lastClick = now }
        }
        if (pinchL && !dragging && now - pinchStart >= DRAG_HOLD_SEC) {
            dragging = true; touch?.dragStart(cx, cy)
        }

        // ---- thumb + middle pinch: Back (Android has no right click) ----
        if (!pinchL) {
            if (!pinchR && dR < PINCH_ON) {
                pinchR = true
                if (now - lastBack > BACK_COOLDOWN) { touch?.back(); lastBack = now }
            } else if (pinchR && dR > PINCH_OFF) pinchR = false
        }

        cur.mode = when {
            dragging -> CursorView.DRAG
            pinchL -> CursorView.PINCH
            pinchR -> CursorView.BACK
            else -> CursorView.MOVE
        }

        // ---- cursor position: palm centre -> filter -> screen ----
        var px = 0f; var py = 0f
        for ((i, w) in ANCHOR) { px += lm[i].x() * w; py += lm[i].y() * w }
        val ax = ((px - mg[0]) / (1f - 2f * mg[0])).coerceIn(0f, 1f)
        val ay = ((py - mg[1]) / (1f - mg[1] - mg[2])).coerceIn(0f, 1f)
        val sx = (fx.filter(ax, now) + fx.vel * PREDICT_SEC).coerceIn(0f, 1f)
        val sy = (fy.filter(ay, now) + fy.vel * PREDICT_SEC).coerceIn(0f, 1f)
        cx = sx * (screenW - 1); cy = sy * (screenH - 1)
        cur.tx = cx; cur.ty = cy
        if (cur.mode == CursorView.HIDDEN) cur.snap = true
        if (dragging) touch?.dragMove(cx, cy)
    }
}
