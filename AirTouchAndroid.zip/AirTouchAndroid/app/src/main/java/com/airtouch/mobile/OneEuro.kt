package com.airtouch.mobile

import kotlin.math.PI
import kotlin.math.abs

/** One-Euro filter (same as the PC script). Returns smoothed value; velocity in [vel]. */
class OneEuro(var minCutoff: Float, var beta: Float, private val dCutoff: Float) {
    private var x = Float.NaN
    private var dx = 0f
    private var t = 0.0
    var vel = 0f
        private set

    private fun alpha(cutoff: Float, dt: Float): Float {
        val tau = 1f / (2f * PI.toFloat() * cutoff)
        return 1f / (1f + tau / dt)
    }

    fun filter(v: Float, tSec: Double): Float {
        if (x.isNaN()) {
            x = v; dx = 0f; t = tSec; vel = 0f
            return v
        }
        val dt = maxOf((tSec - t).toFloat(), 1e-3f)
        t = tSec
        val raw = (v - x) / dt
        dx += alpha(dCutoff, dt) * (raw - dx)
        val cutoff = minCutoff + beta * abs(dx)
        x += alpha(cutoff, dt) * (v - x)
        vel = dx
        return x
    }

    fun reset() { x = Float.NaN; dx = 0f; vel = 0f }
}
